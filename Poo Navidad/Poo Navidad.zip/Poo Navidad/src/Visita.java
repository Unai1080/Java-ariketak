public class Visita {
}
