public class Salon {
}
